Street address parser and formatter


