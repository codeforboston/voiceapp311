Home-page: UNKNOWN
Author: UNKNOWN
Author-email: UNKNOWN
License: UNKNOWN
Description-Content-Type: UNKNOWN
Description: UNKNOWN
Keywords: distutils setuptools package installer

Platform: UNKNOWN
Classifier: Framework :: Setuptools Plugin
Classifier: Topic :: System :: Installation/Setup
